<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('products', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('slug')->unique();
            $table->string('category')->default('essence'); // essence, special, talisman
            $table->unsignedTinyInteger('essence_number')->nullable();
            $table->string('tagline')->nullable();
            $table->text('description')->nullable();
            $table->json('notes')->nullable(); // top, heart, base notes
            $table->decimal('price', 12, 2);
            $table->integer('stock')->default(100);
            $table->string('volume')->default('50ml');
            $table->string('image')->nullable();
            $table->boolean('is_active')->default(true);
            $table->boolean('is_featured')->default(false);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('products');
    }
};
