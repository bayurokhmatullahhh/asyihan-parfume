<?php

namespace App\Http\Controllers;

use App\Models\NumerologyLead;
use App\Services\NumerologyService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class NumerologyController extends Controller
{
    public function __construct(
        protected NumerologyService $numerology
    ) {}

    /**
     * Show the calculator page.
     */
    public function index(): View
    {
        return view('pages.calculator', [
            'archetypes' => $this->numerology->getAllArchetypes(),
            'defaultArchetype' => $this->numerology->getArchetype(7),
        ]);
    }

    /**
     * Calculate numerology from birth date (AJAX).
     */
    public function calculate(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'birth_date' => 'required|date|before_or_equal:today',
            'email' => 'nullable|email|max:255',
            'phone' => 'nullable|string|max:25',
        ]);

        try {
            $reading = $this->numerology->getReading(
                $validated['birth_date'],
                $validated['name']
            );

            // Enrich tokoh data directly at top level for easy JS access
            $reading['tokoh'] = $this->numerology->getTokohForDate(
                $reading['core_number'],
                $validated['birth_date']
            );

            // Capture lead into database silently
            try {
                NumerologyLead::create([
                    'user_id' => auth()->id(),
                    'full_name' => $validated['name'],
                    'birth_date' => $validated['birth_date'],
                    'phone' => $validated['phone'] ?? auth()->user()?->phone,
                    'email' => $validated['email'] ?? auth()->user()?->email,
                    'core_number' => $reading['core_number'],
                    'archetype_name' => $reading['archetype']['name'] ?? 'Essence '.$reading['core_number'],
                    'ip_address' => $request->ip(),
                    'user_agent' => $request->userAgent(),
                ]);
            } catch (\Throwable $th) {
                // Silently ignore to not disrupt calculator UX
                report($th);
            }

            return response()->json([
                'success' => true,
                'data' => $reading,
            ]);
        } catch (\InvalidArgumentException $e) {
            return response()->json([
                'success' => false,
                'message' => 'Tanggal lahir tidak valid.',
            ], 422);
        }
    }
}
