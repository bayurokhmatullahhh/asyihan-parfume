@extends('layouts.app')

@section('title', 'Gerbang Pembayaran Sakral #' . $order->order_number . ' — ASYIHAN')

@section('content')
<div class="py-12 md:py-16 px-4 sm:px-6 max-w-4xl mx-auto">
    <!-- Breadcrumb -->
    <div class="flex items-center gap-2 text-[10px] tracking-[0.2em] uppercase text-zinc-500 font-serif mb-6">
        <a href="{{ route('home') }}" class="hover:text-amber-400 transition-colors">Beranda</a>
        <span>/</span>
        <a href="{{ route('cart.index') }}" class="hover:text-amber-400 transition-colors">Keranjang</a>
        <span>/</span>
        <span class="text-amber-400/90">Gerbang Pembayaran</span>
    </div>

    <!-- Header -->
    <div class="text-center max-w-xl mx-auto mb-10">
        <div class="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-amber-400/10 border border-amber-400/30 text-amber-300 text-[11px] font-serif uppercase tracking-widest mb-3">
            <span class="w-1.5 h-1.5 rounded-full bg-amber-400 inline-block shadow-[0_0_8px_rgba(251,191,36,0.6)]"></span>
            GERBANG TRANSAKSI SAKRAL
        </div>
        <h1 class="font-serif text-3xl sm:text-4xl text-amber-100 font-normal tracking-wide">
            Selesaikan Penyelarasan Mahakarya
        </h1>
        <p class="text-xs sm:text-sm text-zinc-400 mt-2 font-light leading-relaxed">
            Pesanan Anda telah diinisiasi dengan nomor <span class="text-amber-300 font-mono font-semibold">#{{ $order->order_number }}</span>. Lanjutkan ke gerbang pembayaran aman Midtrans untuk memproses persembahan wewangian Anda.
        </p>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-12 gap-8">
        <!-- Left: Payment Action Card (7 cols) -->
        <div class="md:col-span-7 space-y-6">
            <div class="bg-[#131313] border border-amber-500/30 rounded-2xl p-6 sm:p-8 shadow-2xl relative overflow-hidden">
                <div class="absolute -right-12 -top-12 w-48 h-48 bg-amber-500/5 rounded-full blur-3xl pointer-events-none"></div>

                <!-- Status Badge & 24-Hour Countdown Timer -->
                <div class="border-b border-zinc-800 pb-4 mb-6">
                    <div class="flex items-center justify-between mb-3">
                        <div class="text-xs font-serif uppercase tracking-wider text-zinc-400">Status Transaksi</div>
                        @if($order->isExpired() || $order->status === 'cancelled')
                            <span class="px-3 py-1 rounded-full bg-rose-500/10 border border-rose-500/40 text-rose-300 text-xs font-mono flex items-center gap-1.5">
                                <span class="w-2 h-2 rounded-full bg-rose-400"></span>
                                Kedaluwarsa / Dibatalkan
                            </span>
                        @else
                            <span class="px-3 py-1 rounded-full bg-amber-400/10 border border-amber-400/40 text-amber-300 text-xs font-mono flex items-center gap-1.5">
                                <span class="w-2 h-2 rounded-full bg-amber-400 animate-pulse"></span>
                                Menunggu Pembayaran
                            </span>
                        @endif
                    </div>

                    <!-- 24-Hour Countdown Banner -->
                    @if(! $order->isPaid() && ! $order->isExpired() && $order->status !== 'cancelled')
                        <div class="p-3.5 rounded-xl bg-gradient-to-r from-amber-950/40 via-black/80 to-amber-950/40 border border-amber-500/30 flex items-center justify-between gap-3">
                            <div class="flex items-center gap-2.5">
                                <span class="text-base">⏳</span>
                                <div>
                                    <div class="text-[10px] uppercase font-mono tracking-widest text-amber-400 font-semibold">BATAS WAKTU PEMBAYARAN (24 JAM)</div>
                                    <div class="text-[11px] text-zinc-400">Selesaikan sebelum: <span class="text-zinc-200 font-mono">{{ $order->expires_at ? $order->expires_at->format('d M Y, H:i') : now()->addHours(24)->format('d M Y, H:i') }} WIB</span></div>
                                </div>
                            </div>
                            <!-- Countdown Counter -->
                            <div class="flex items-center gap-1 font-mono text-amber-300 font-bold text-sm bg-black/70 px-3 py-1.5 rounded-lg border border-amber-500/40 shrink-0" id="countdown-box">
                                <span id="cd-hours">00</span><span class="text-amber-500 animate-pulse">:</span>
                                <span id="cd-mins">00</span><span class="text-amber-500 animate-pulse">:</span>
                                <span id="cd-secs">00</span>
                            </div>
                        </div>
                    @elseif($order->isExpired() || $order->status === 'cancelled')
                        <div class="p-3.5 rounded-xl bg-rose-950/30 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2">
                            <span>⚠️</span>
                            <span>Batas waktu pembayaran 24 jam telah berakhir. Pesanan ini telah otomatis dibatalkan oleh sistem.</span>
                        </div>
                    @endif
                </div>

                <!-- Total Amount Highlight -->
                <div class="text-center py-4 bg-black/50 border border-amber-900/30 rounded-xl mb-6">
                    <div class="text-[10px] uppercase tracking-widest font-mono text-zinc-400 mb-1">TOTAL YANG HARUS DIBAYAR</div>
                    <div class="font-serif text-3xl sm:text-4xl text-amber-200 font-bold tracking-tight">
                        {{ $order->formatted_total_price }}
                    </div>
                    <div class="text-[10px] text-zinc-500 mt-1">Termasuk PPN & Biaya Pengiriman Sakral</div>
                </div>

                <!-- Midtrans Snap Trigger Button -->
                @if(! $order->isExpired() && $order->status !== 'cancelled')
                    <button type="button" id="payButton"
                        class="w-full py-4 px-6 rounded-xl bg-gradient-to-r from-amber-400 via-amber-500 to-yellow-500 hover:from-amber-300 hover:to-yellow-400 text-black font-serif font-bold text-sm uppercase tracking-wider shadow-lg shadow-amber-500/20 hover:shadow-amber-500/40 transition-all flex items-center justify-center gap-2 group cursor-pointer">
                        <svg class="w-5 h-5 text-black" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 9V7a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2m2 4h10a2 2 0 002-2v-6a2 2 0 00-2-2H9a2 2 0 00-2 2v6a2 2 0 002 2zm7-5a2 2 0 11-4 0 2 2 0 014 0z"/>
                        </svg>
                        <span>BAYAR SEKARANG — {{ $order->formatted_total_price }}</span>
                    </button>
                @else
                    <div class="text-center py-3 px-4 rounded-xl bg-zinc-900 border border-zinc-800 text-zinc-500 font-serif text-xs">
                        Pembayaran telah ditutup karena pesanan melewati batas waktu 24 jam.
                        <div class="mt-2">
                            <a href="{{ route('order') }}" class="text-amber-400 hover:underline font-mono text-[11px]">Inisiasi Pesanan Baru →</a>
                        </div>
                    </div>
                @endif

                <!-- Active Payment Method -->
                <div class="mt-6 pt-6 border-t border-zinc-800">
                    <div class="text-[10px] uppercase tracking-widest text-zinc-500 font-mono mb-3 text-center">METODE PEMBAYARAN TERPILIH</div>
                    <div class="flex flex-wrap justify-center items-center gap-3 text-xs font-mono">
                        @php
                            $paymentMethodLabels = [
                                'qris' => ['label' => 'QRIS INSTAN', 'desc' => 'GoPay, OVO, Dana'],
                                'va' => ['label' => 'VIRTUAL ACCOUNT', 'desc' => 'BCA, Mandiri, BRI, BNI'],
                                'cc' => ['label' => 'KARTU KREDIT', 'desc' => 'Visa, Mastercard'],
                                'shopeepay' => ['label' => 'SHOPEEPAY', 'desc' => 'Auto Redirection'],
                            ];
                            $activeMethod = $order->payment_method ?? 'qris';
                        @endphp
                        @foreach($paymentMethodLabels as $key => $method)
                            <div class="px-3 py-2 rounded-lg text-center {{ $key === $activeMethod ? 'bg-amber-400/10 border border-amber-400/60 text-amber-200' : 'bg-black/60 border border-zinc-800 text-zinc-500' }}">
                                <div class="text-xs font-bold {{ $key === $activeMethod ? 'text-amber-200' : 'text-zinc-500' }}">{{ $method['label'] }}</div>
                                <div class="text-[9px] {{ $key === $activeMethod ? 'text-amber-400/80' : 'text-zinc-600' }}">{{ $method['desc'] }}</div>
                            </div>
                        @endforeach
                    </div>
                </div>


            </div>

            <!-- Alternative / Customer Support -->
            <div class="bg-[#131313]/60 border border-zinc-800 rounded-2xl p-5 flex items-center justify-between gap-4">
                <div>
                    <div class="text-xs font-serif text-zinc-300 font-medium">Mengalami Kendala Pembayaran?</div>
                    <div class="text-[11px] text-zinc-500 font-light mt-0.5">Para peracik kami siap membantu verifikasi manual via WhatsApp.</div>
                </div>
                <a href="https://wa.me/6281234567890?text={{ urlencode('Halo Sanctum Asyihan, saya ingin konfirmasi pembayaran pesanan #' . $order->order_number) }}" 
                   target="_blank"
                   class="px-4 py-2 rounded-xl border border-zinc-700 text-zinc-300 hover:text-amber-300 hover:border-amber-400/40 text-xs font-serif tracking-wider whitespace-nowrap transition-colors">
                    Hubungi Penjaga
                </a>
            </div>
        </div>

        <!-- Right: Order Summary Sidebar (5 cols) -->
        <div class="md:col-span-5 space-y-4">
            <div class="bg-[#131313] border border-amber-900/30 rounded-2xl p-6 shadow-xl space-y-5">
                <div class="border-b border-zinc-800 pb-3">
                    <div class="text-[10px] uppercase tracking-widest text-amber-400/80 font-mono">RINCIAN PESANAN</div>
                    <h3 class="font-serif text-lg text-amber-100 font-medium mt-0.5">#{{ $order->order_number }}</h3>
                </div>

                <!-- Items list -->
                <div class="space-y-3">
                    @foreach($order->items as $item)
                        <div class="flex items-center justify-between text-xs py-1 border-b border-zinc-800/40 pb-2">
                            <div class="min-w-0 pr-3">
                                <div class="font-serif text-zinc-200 font-medium truncate">{{ $item->product_name }}</div>
                                <div class="text-[10px] text-zinc-500">{{ $item->quantity }}x @ Rp {{ number_format($item->price, 0, ',', '.') }}</div>
                            </div>
                            <div class="font-mono text-amber-200 font-semibold text-right flex-shrink-0">
                                {{ $item->formatted_subtotal }}
                            </div>
                        </div>
                    @endforeach
                </div>

                <!-- Delivery & Shipping -->
                <div class="space-y-2 text-xs border-b border-zinc-800 pb-3">
                    <div class="flex justify-between text-zinc-400">
                        <span>Ongkos Pengiriman</span>
                        <span class="font-mono text-zinc-300">
                            {{ $order->shipping_cost > 0 ? 'Rp ' . number_format($order->shipping_cost, 0, ',', '.') : 'GRATIS' }}
                        </span>
                    </div>
                    <div class="flex justify-between text-zinc-400">
                        <span>Layanan Kurir</span>
                        <span class="font-serif text-amber-200/80 text-[11px]">{{ ucfirst($order->expedition) }}</span>
                    </div>
                </div>

                <!-- Destination -->
                <div class="text-xs text-zinc-400 space-y-1">
                    <div class="text-[10px] uppercase font-mono text-zinc-500">Tujuan Pengiriman:</div>
                    <div class="text-zinc-300 font-serif">{{ $order->name }} ({{ $order->phone }})</div>
                    <div class="text-zinc-400 text-[11px] leading-relaxed">{{ $order->address }}, {{ $order->city }}, {{ $order->province }} {{ $order->postal_code }}</div>
                </div>

                <!-- Total -->
                <div class="border-t border-amber-900/40 pt-4 flex justify-between items-baseline">
                    <span class="font-serif text-sm text-zinc-300">Total Pembayaran</span>
                    <span class="font-serif text-xl text-amber-200 font-bold">{{ $order->formatted_total_price }}</span>
                </div>
            </div>
        </div>
    </div>
</div>

@push('scripts')
<script src="{{ $snapJsUrl ?? (config('midtrans.is_production') ? 'https://app.midtrans.com/snap/snap.js' : 'https://app.sandbox.midtrans.com/snap/snap.js') }}" data-client-key="{{ $clientKey }}"></script>
<script>
    const payButton = document.getElementById('payButton');
    const snapToken = "{{ $snapToken }}";

    if (payButton) {
        payButton.addEventListener('click', function() {
            if (typeof window.snap === 'undefined') {
                alert('Midtrans Snap SDK belum termuat. Pastikan koneksi internet Anda stabil dan refresh halaman ini.');
                return;
            }

            window.snap.pay(snapToken, {
                onSuccess: function(result) {
                    window.location.href = "{{ route('payment.finish') }}?order_id={{ $order->order_number }}&transaction_status=settlement";
                },
                onPending: function(result) {
                    window.location.href = "{{ route('payment.finish') }}?order_id={{ $order->order_number }}&transaction_status=pending";
                },
                onError: function(result) {
                    alert('Pembayaran gagal atau dibatalkan. Silakan coba metode lain.');
                },
                onClose: function() {
                    // User closed the popup without finishing payment
                }
            });
        });
    }

    // 24-Hour Countdown Timer Logic
    const remainingSeconds = {{ $order->remaining_seconds }};
    let timeLeft = remainingSeconds;

    const elHours = document.getElementById('cd-hours');
    const elMins = document.getElementById('cd-mins');
    const elSecs = document.getElementById('cd-secs');

    function updateCountdown() {
        if (timeLeft <= 0) {
            if (elHours) elHours.textContent = '00';
            if (elMins) elMins.textContent = '00';
            if (elSecs) elSecs.textContent = '00';
            const box = document.getElementById('countdown-box');
            if (box) {
                box.classList.remove('text-amber-300', 'border-amber-500/40');
                box.classList.add('text-rose-400', 'border-rose-500/40');
            }
            return;
        }

        const hours = Math.floor(timeLeft / 3600);
        const minutes = Math.floor((timeLeft % 3600) / 60);
        const seconds = timeLeft % 60;

        if (elHours) elHours.textContent = String(hours).padStart(2, '0');
        if (elMins) elMins.textContent = String(minutes).padStart(2, '0');
        if (elSecs) elSecs.textContent = String(seconds).padStart(2, '0');

        timeLeft--;
    }

    if (elHours && timeLeft > 0) {
        updateCountdown();
        setInterval(updateCountdown, 1000);
    }
</script>
@endpush
@endsection
