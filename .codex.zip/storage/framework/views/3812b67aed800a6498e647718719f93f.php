<?php $__env->startSection('title', 'Tambah Mahakarya Baru — ASYIHAN Admin'); ?>
<?php $__env->startSection('page_title', 'Persembahkan Mahakarya Baru'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-3xl space-y-6">
    <a href="<?php echo e(route('admin.products.index')); ?>" class="text-xs text-gold-400/80 hover:text-gold-300 flex items-center gap-1.5 transition-colors">
        ← Kembali ke Katalog
    </a>

    <div class="bg-[#0e0e0e] border border-gold-400/25 rounded-2xl p-6 sm:p-8 shadow-[0_4px_25px_rgba(0,0,0,0.6)]">
        <?php if($errors->any()): ?>
            <div class="mb-6 p-4 rounded-xl bg-rose-950/70 border border-rose-500/30 text-rose-200 text-xs">
                <ul class="list-disc list-inside space-y-1">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <form action="<?php echo e(route('admin.products.store')); ?>" method="POST" class="space-y-5 text-xs">
            <?php echo csrf_field(); ?>

            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div class="sm:col-span-2">
                    <label class="block uppercase tracking-wider text-slate-300 mb-1.5 font-light">
                        Nama Mahakarya <span class="text-gold-400">*</span>
                    </label>
                    <input type="text" name="name" value="<?php echo e(old('name')); ?>" required
                        class="w-full px-4 py-3 bg-black/80 border border-gold-400/25 rounded-xl text-slate-100 placeholder-slate-600 focus:outline-none focus:border-gold-400"
                        placeholder="Contoh: ASYIHAN ESSENCE I — SANG PENGGAGAS">
                </div>

                <div>
                    <label class="block uppercase tracking-wider text-slate-300 mb-1.5 font-light">
                        Kategori <span class="text-gold-400">*</span>
                    </label>
                    <select name="category" required class="w-full px-4 py-3 bg-black/80 border border-gold-400/25 rounded-xl text-slate-100 focus:outline-none focus:border-gold-400">
                        <option value="essence" <?php echo e(old('category') === 'essence' ? 'selected' : ''); ?>>9 Essence Numerologi</option>
                        <option value="special" <?php echo e(old('category') === 'special' ? 'selected' : ''); ?>>Special Offering</option>
                        <option value="talisman" <?php echo e(old('category') === 'talisman' ? 'selected' : ''); ?>>Talisman / Lilin</option>
                    </select>
                </div>

                <div>
                    <label class="block uppercase tracking-wider text-slate-300 mb-1.5 font-light">
                        Nomor Esensi (1 - 9)
                    </label>
                    <input type="number" name="essence_number" value="<?php echo e(old('essence_number')); ?>" min="1" max="999"
                        class="w-full px-4 py-3 bg-black/80 border border-gold-400/25 rounded-xl text-slate-100 placeholder-slate-600 focus:outline-none focus:border-gold-400"
                        placeholder="1">
                </div>

                <div class="sm:col-span-2">
                    <label class="block uppercase tracking-wider text-slate-300 mb-1.5 font-light">
                        Tagline Filosofi
                    </label>
                    <input type="text" name="tagline" value="<?php echo e(old('tagline')); ?>"
                        class="w-full px-4 py-3 bg-black/80 border border-gold-400/25 rounded-xl text-slate-100 placeholder-slate-600 focus:outline-none focus:border-gold-400"
                        placeholder="Aku Tidak Menunggu. Aku Memulai.">
                </div>

                <div class="sm:col-span-2">
                    <label class="block uppercase tracking-wider text-slate-300 mb-1.5 font-light">
                        Deskripsi Mahakarya & Karakter Wewangian
                    </label>
                    <textarea name="description" rows="3"
                        class="w-full px-4 py-3 bg-black/80 border border-gold-400/25 rounded-xl text-slate-100 placeholder-slate-600 focus:outline-none focus:border-gold-400"
                        placeholder="Aroma yang diawali dengan kesan segar dari Bergamot..."><?php echo e(old('description')); ?></textarea>
                </div>

                <div>
                    <label class="block uppercase tracking-wider text-slate-300 mb-1.5 font-light">
                        Harga Investasi (Rp) <span class="text-gold-400">*</span>
                    </label>
                    <input type="number" name="price" value="<?php echo e(old('price', 350000)); ?>" required min="0" step="1000"
                        class="w-full px-4 py-3 bg-black/80 border border-gold-400/25 rounded-xl text-slate-100 focus:outline-none focus:border-gold-400">
                </div>

                <div>
                    <label class="block uppercase tracking-wider text-slate-300 mb-1.5 font-light">
                        Stok Tersedia <span class="text-gold-400">*</span>
                    </label>
                    <input type="number" name="stock" value="<?php echo e(old('stock', 50)); ?>" required min="0"
                        class="w-full px-4 py-3 bg-black/80 border border-gold-400/25 rounded-xl text-slate-100 focus:outline-none focus:border-gold-400">
                </div>

                <div>
                    <label class="block uppercase tracking-wider text-slate-300 mb-1.5 font-light">
                        Volume / Ukuran <span class="text-gold-400">*</span>
                    </label>
                    <input type="text" name="volume" value="<?php echo e(old('volume', '50ml')); ?>" required
                        class="w-full px-4 py-3 bg-black/80 border border-gold-400/25 rounded-xl text-slate-100 focus:outline-none focus:border-gold-400"
                        placeholder="50ml">
                </div>

                <div>
                    <label class="block uppercase tracking-wider text-slate-300 mb-1.5 font-light">
                        Jalur Gambar Botol
                    </label>
                    <input type="text" name="image" value="<?php echo e(old('image', 'images/bottle/bottle_1.png')); ?>"
                        class="w-full px-4 py-3 bg-black/80 border border-gold-400/25 rounded-xl text-slate-100 focus:outline-none focus:border-gold-400">
                </div>

                <div class="sm:col-span-2 flex items-center gap-6 pt-2">
                    <label class="flex items-center gap-2 cursor-pointer">
                        <input type="checkbox" name="is_active" value="1" <?php echo e(old('is_active', true) ? 'checked' : ''); ?>

                            class="rounded border-gold-400/40 bg-black text-gold-500 focus:ring-gold-400/40">
                        <span class="text-slate-200">Aktifkan Mahakarya (Tampil di Katalog)</span>
                    </label>

                    <label class="flex items-center gap-2 cursor-pointer">
                        <input type="checkbox" name="is_featured" value="1" <?php echo e(old('is_featured') ? 'checked' : ''); ?>

                            class="rounded border-gold-400/40 bg-black text-gold-500 focus:ring-gold-400/40">
                        <span class="text-slate-200">Sorot Unggulan (Featured)</span>
                    </label>
                </div>
            </div>

            <div class="pt-4 border-t border-white/5 flex justify-end gap-3">
                <a href="<?php echo e(route('admin.products.index')); ?>" class="px-5 py-2.5 rounded-xl border border-white/20 text-slate-300 hover:bg-white/5 transition-all">
                    Batal
                </a>
                <button type="submit"
                    class="px-6 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-600 text-black font-semibold uppercase tracking-wider shadow-md hover:brightness-110 transition-all">
                    Simpan Mahakarya
                </button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\asyihan-parfume\resources\views/admin/products/create.blade.php ENDPATH**/ ?>