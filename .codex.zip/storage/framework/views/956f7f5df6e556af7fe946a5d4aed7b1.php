<?php $__env->startSection('title', 'Katalog Altar Produk — ASYIHAN Admin'); ?>
<?php $__env->startSection('page_title', 'Katalog Mahakarya Wewangian'); ?>

<?php $__env->startSection('content'); ?>
<div class="space-y-6">
    <!-- Header with Create Button -->
    <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
            <p class="text-xs text-slate-400 font-light">Kelola koleksi flacon esensi numerologi, persembahan khusus, dan wewangian sakral.</p>
        </div>
        <div class="flex items-center gap-3">
            <a href="<?php echo e(route('admin.categories.index')); ?>"
                class="px-3.5 py-2 rounded-xl bg-black/80 border border-gold-400/30 text-gold-300 hover:bg-gold-400/10 font-medium text-xs transition-all flex items-center gap-1.5">
                <span>📂 Kelola Kategori</span>
            </a>
            <a href="<?php echo e(route('admin.products.create')); ?>"
                class="px-4 py-2 rounded-xl bg-gradient-to-r from-amber-500 via-gold-400 to-yellow-600 text-black font-semibold text-xs uppercase tracking-wider shadow-[0_0_15px_rgba(212,175,55,0.3)] hover:brightness-110 transition-all flex items-center gap-2">
                <span>+ Tambah Mahakarya Baru</span>
            </a>
        </div>
    </div>

    <!-- Filter & Search Bar -->
    <div class="bg-[#0e0e0e] border border-gold-400/20 rounded-2xl p-5 shadow-[0_4px_25px_rgba(0,0,0,0.6)]">
        <form action="<?php echo e(route('admin.products.index')); ?>" method="GET" class="flex flex-col sm:flex-row gap-4 justify-between items-center">
            <!-- Category Tabs -->
            <div class="flex flex-wrap gap-2 w-full sm:w-auto">
                <a href="<?php echo e(route('admin.products.index')); ?>"
                    class="px-3.5 py-1.5 rounded-lg text-xs font-mono transition-all <?php echo e(!request('category_id') && !request('category') ? 'bg-gold-400 text-black font-bold' : 'bg-black/60 text-slate-400 hover:text-gold-300 border border-white/5'); ?>">
                    Semua (<?php echo e(\App\Models\Product::count()); ?>)
                </a>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('admin.products.index', ['category_id' => $cat->id])); ?>"
                        class="px-3.5 py-1.5 rounded-lg text-xs font-mono transition-all <?php echo e(request('category_id') == $cat->id || request('category') === $cat->slug ? 'bg-gold-400 text-black font-bold' : 'bg-black/60 text-slate-400 hover:text-gold-300 border border-white/5'); ?>">
                        <?php echo e($cat->name); ?> (<?php echo e($cat->products_count ?? $cat->products()->count()); ?>)
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <!-- Search Input -->
            <div class="flex items-center gap-2 w-full sm:w-72">
                <input type="text" name="search" value="<?php echo e(request('search')); ?>" placeholder="Cari nama atau tagline..."
                    class="w-full px-3.5 py-2 bg-black/80 border border-gold-400/25 rounded-xl text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-gold-400">
                <button type="submit" class="px-3 py-2 bg-gold-400/20 border border-gold-400/40 rounded-xl text-gold-300 text-xs hover:bg-gold-400/30 transition-all">
                    Cari
                </button>
            </div>
        </form>
    </div>

    <!-- Products Table -->
    <div class="bg-[#0e0e0e] border border-gold-400/25 rounded-2xl overflow-hidden shadow-[0_4px_25px_rgba(0,0,0,0.6)]">
        <div class="overflow-x-auto">
            <table class="w-full text-xs text-left">
                <thead class="bg-black/80 text-[10px] uppercase font-mono tracking-wider text-slate-400 border-b border-white/10">
                    <tr>
                        <th class="py-3.5 px-4 text-center">Botol</th>
                        <th class="py-3.5 px-4">Nama Produk & Karakter</th>
                        <th class="py-3.5 px-4 text-center">Kategori</th>
                        <th class="py-3.5 px-4 text-center">Stok</th>
                        <th class="py-3.5 px-4 text-right">Harga</th>
                        <th class="py-3.5 px-4 text-center">Status</th>
                        <th class="py-3.5 px-4 text-center">Aksi</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-white/5">
                    <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="hover:bg-white/[0.02] transition-colors">
                            <td class="py-3 px-4 text-center">
                                <div class="w-12 h-12 mx-auto bg-black/80 rounded-xl border border-gold-400/20 p-1 flex items-center justify-center overflow-hidden">
                                    <img src="<?php echo e($product->image_url); ?>" alt="<?php echo e($product->name); ?>" class="max-h-full max-w-full object-contain">
                                </div>
                            </td>
                            <td class="py-3 px-4">
                                <div class="flex items-center gap-2">
                                    <span class="font-medium text-slate-100 font-serif"><?php echo e($product->name); ?></span>
                                    <?php if($product->is_featured): ?>
                                        <span class="px-1.5 py-0.2 text-[8px] uppercase tracking-wider font-mono rounded bg-amber-500/20 text-amber-300 border border-amber-500/30">★ Featured</span>
                                    <?php endif; ?>
                                </div>
                                <span class="text-[10px] text-slate-400 italic block mt-0.5"><?php echo e($product->tagline); ?></span>
                                <?php if($product->soul_character): ?>
                                    <span class="text-[9px] text-amber-400/80 font-mono block mt-1 line-clamp-1">✦ Jiwa: <?php echo e(Str::limit($product->soul_character, 70)); ?></span>
                                <?php endif; ?>
                            </td>
                            <td class="py-3 px-4 text-center">
                                <span class="px-2.5 py-1 rounded-full text-[10px] uppercase font-mono border <?php echo e($product->category === 'essence' ? 'bg-amber-500/15 text-amber-300 border-amber-500/30' : 'bg-purple-500/15 text-purple-300 border-purple-500/30'); ?>">
                                    <?php echo e($product->categoryRelation?->name ?? strtoupper($product->category)); ?>

                                </span>
                            </td>
                            <td class="py-3 px-4 text-center font-mono text-slate-300">
                                <span class="<?php echo e($product->stock <= 5 ? 'text-rose-400 font-bold' : ''); ?>">
                                    <?php echo e($product->stock); ?>

                                </span>
                            </td>
                            <td class="py-3 px-4 text-right font-mono text-gold-300 font-medium">
                                <?php echo e($product->formatted_price); ?>

                            </td>
                            <td class="py-3 px-4 text-center">
                                <form action="<?php echo e(route('admin.products.toggle', $product)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PUT'); ?>
                                    <button type="submit" class="px-2.5 py-0.5 rounded-full text-[10px] font-mono border transition-all <?php echo e($product->is_active ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40 hover:bg-emerald-500/30' : 'bg-rose-500/20 text-rose-300 border-rose-500/40 hover:bg-rose-500/30'); ?>">
                                        <?php echo e($product->is_active ? 'Aktif' : 'Nonaktif'); ?>

                                    </button>
                                </form>
                            </td>
                            <td class="py-3 px-4 text-center">
                                <div class="flex items-center justify-center gap-2">
                                    <a href="<?php echo e(route('admin.products.edit', $product)); ?>"
                                        class="px-2.5 py-1 rounded bg-gold-400/15 border border-gold-400/30 text-gold-300 text-[11px] hover:bg-gold-400/25 transition-all">
                                        Edit
                                    </a>
                                    <form action="<?php echo e(route('admin.products.destroy', $product)); ?>" method="POST" onsubmit="return confirm('Hapus produk ini dari katalog?')">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="p-1 rounded text-rose-400/70 hover:text-rose-300 hover:bg-rose-500/10 transition-colors" title="Hapus">
                                            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/></svg>
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="7" class="py-12 text-center text-slate-500">Tidak ada produk dalam katalog.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <?php if($products->hasPages()): ?>
            <div class="p-4 border-t border-white/5">
                <?php echo e($products->links()); ?>

            </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\asyihan-parfume\resources\views/admin/products/index.blade.php ENDPATH**/ ?>